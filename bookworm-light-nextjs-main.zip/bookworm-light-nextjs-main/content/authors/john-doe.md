---
title: John Doe
image: /images/authors/john-doe.jpg
description: this is meta description
social:
  facebook: https://www.facebook.com/
  twitter: https://www.twitter.com/
  instagram: https://www.instagram.com/
---

lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostr navigation et dolore magna aliqua.
