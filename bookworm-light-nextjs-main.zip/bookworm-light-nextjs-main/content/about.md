---
title: "I’m John Doe, A content writer based in LDN, currently at Bookworm"
meta_title: "About"
image: "/images/author.jpg"
layout: "about"
draft: false

# social sites
social:
  facebook: "https://www.facebook.com"
  twitter: "https://www.twitter.com"
  instagram: "https://www.instagram.com"
---

A content writer with over 12 years experience working across brand identity, publishing and digital products. Maecenas sit amet purus eget ipsum elementum venenatis. Aenean maximus urna magna elementum venenatis, quis rutrum mi semper non purus eget.

Purus eget ipsum elementum venenatis. Aenean maximus urna magna elementum venenatis, quis rutrum mi semper non purus eget ipsum elementum venenatis.
