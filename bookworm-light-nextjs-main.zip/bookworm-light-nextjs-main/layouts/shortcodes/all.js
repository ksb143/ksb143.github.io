import Button from "./Button";

const shortcodes = {
  Button,
};

export default shortcodes;
