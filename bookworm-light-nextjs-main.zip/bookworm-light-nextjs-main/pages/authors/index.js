import AuthorPagination, { getStaticProps } from "./page/[slug]";

export { getStaticProps };
export default AuthorPagination;
